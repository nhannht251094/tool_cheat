const DEFAULT_CONFIG = {
  endpoint: "https://cheat.staging.enostd.gay/9703/inputed",
  serviceId: "9703",
  userId: "game_rampusd01",
  currency: "USD",
  matrixData: "C3,C3,C2,C3,C3,C3,K,C3,A,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3",
  tableFormat: "4,4,4,4,4",
  powerUpSymbolCode:
    "C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3",
  bearerToken: ""
};

const LEGACY_DOCK_ALLOWED_SITES = [
  "https://cheat.staging.enostd.gay/*",
  "https://iframe-tektale.staging.enostd.gay/*",
  "https://cheat.doithe47.com/*",
  "http://www.rampnhan.online/*",
  "https://www.rampnhan.online/*",
  "https://nhannht251094.github.io/tool_cheat/*",
  "http://localhost/*",
  "http://127.0.0.1/*"
];

const DEFAULT_DOCK_ALLOWED_SITES = [];

const DEFAULT_DOCK_CONFIG = {
  dockEnabled: true,
  dockAllowedSites: DEFAULT_DOCK_ALLOWED_SITES
};

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get({ dockAllowedSites: [] });
  const sites = Array.isArray(stored.dockAllowedSites) ? stored.dockAllowedSites : [];
  const legacySites = new Set(LEGACY_DOCK_ALLOWED_SITES);
  const manualSites = sites.filter((site) => !legacySites.has(site));
  if (manualSites.length !== sites.length) {
    await chrome.storage.local.set({ dockAllowedSites: manualSites });
  }
});

function sitePatternFromUrl(url) {
  try {
    const parsed = new URL(url);
    if (!["http:", "https:"].includes(parsed.protocol)) return "";
    return `${parsed.origin}/*`;
  } catch {
    return "";
  }
}

async function getDockConfig() {
  const stored = await chrome.storage.local.get(DEFAULT_DOCK_CONFIG);
  return { ...DEFAULT_DOCK_CONFIG, ...stored };
}

async function saveAllowedSite(pattern) {
  const value = String(pattern || "").trim();
  if (!value) return { ok: false, error: "Missing URL pattern" };
  const config = await getDockConfig();
  const sites = Array.isArray(config.dockAllowedSites) ? config.dockAllowedSites : [];
  const nextSites = [value, ...sites.filter((site) => site !== value)];
  await chrome.storage.local.set({
    dockEnabled: true,
    dockAllowedSites: nextSites
  });
  return { ok: true, dockAllowedSites: nextSites };
}

async function openDockOnTab(tabId) {
  try {
    const response = await chrome.tabs.sendMessage(tabId, { type: "SLOT_MATRIX_SHOW_DOCK" });
    if (response?.ok) return response;
  } catch {
    // The content script may have exited because this site was not allowed yet.
  }

  await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      sessionStorage.setItem("slotMatrixDockOpenOnce", "true");
      sessionStorage.removeItem("slotMatrixDockHidden");
    }
  });
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["content.js"]
  });
  return { ok: true };
}

const DEFAULT_FORMS = [
  {
    id: "inputed-sample",
    name: "Inputed Sample",
    config: DEFAULT_CONFIG
  },
  {
    id: "all-c3",
    name: "All C3",
    config: {
      ...DEFAULT_CONFIG,
      matrixData: "C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3,C3"
    }
  }
];

const DEFAULT_PROJECTS = [
  {
    id: "project-rampus-inputed",
    name: "RampUSD Inputed",
    serviceId: "9703"
  }
];

async function getConfig() {
  const stored = await chrome.storage.local.get({
    ...DEFAULT_CONFIG,
    ...DEFAULT_DOCK_CONFIG,
    dockUserId: "",
    forms: DEFAULT_FORMS,
    currentFormId: "",
    currentProjectId: DEFAULT_PROJECTS[0].id,
    formsByProject: {},
    currentFormIdsByProject: {}
  });
  const projectForms = stored.formsByProject?.[stored.currentProjectId];
  const forms = projectForms?.length ? projectForms : stored.forms;
  const currentFormId =
    stored.currentFormIdsByProject?.[stored.currentProjectId] || stored.currentFormId;
  const currentForm = forms.find((form) => form.id === currentFormId) || forms[0];
  const storedDefaults = Object.fromEntries(
    Object.keys(DEFAULT_CONFIG).map((key) => [key, stored[key]])
  );
  const config = {
    ...DEFAULT_CONFIG,
    ...storedDefaults,
    ...(currentForm?.config || {}),
    ...DEFAULT_DOCK_CONFIG,
    dockEnabled: stored.dockEnabled,
    dockAllowedSites: stored.dockAllowedSites
  };
  const storedDockUserId = String(stored.dockUserId || "").trim();
  if (storedDockUserId) config.userId = storedDockUserId;
  return config;
}

async function getForms(projectId) {
  const stored = await chrome.storage.local.get({
    forms: DEFAULT_FORMS,
    currentFormId: "",
    currentProjectId: DEFAULT_PROJECTS[0].id,
    formsByProject: {},
    currentFormIdsByProject: {}
  });
  const currentProjectId = projectId || stored.currentProjectId || DEFAULT_PROJECTS[0].id;
  const projectForms = stored.formsByProject?.[currentProjectId];
  const forms = projectId
    ? projectForms?.length
      ? projectForms
      : []
    : projectForms?.length
      ? projectForms
      : stored.forms?.length
        ? stored.forms
        : DEFAULT_FORMS;
  const currentFormId =
    stored.currentFormIdsByProject?.[currentProjectId] || stored.currentFormId || forms[0]?.id || "";
  return { forms, currentFormId, currentProjectId };
}

async function getProjects() {
  const stored = await chrome.storage.local.get({
    projects: DEFAULT_PROJECTS,
    currentProjectId: DEFAULT_PROJECTS[0].id
  });
  return {
    projects: stored.projects?.length ? stored.projects : DEFAULT_PROJECTS,
    currentProjectId: stored.currentProjectId || stored.projects?.[0]?.id || DEFAULT_PROJECTS[0].id
  };
}

async function broadcastDockData(data) {
  const tabs = await chrome.tabs.query({});
  await Promise.allSettled(
    tabs
      .filter((tab) => typeof tab.id === "number")
      .map((tab) =>
        chrome.tabs.sendMessage(tab.id, {
          type: "SLOT_MATRIX_DOCK_DATA_UPDATED",
          ...data
        })
      )
  );
}

function toFormBody(config) {
  const params = new URLSearchParams();
  const skipKeys = new Set([
    "endpoint",
    "bearerToken",
    "token",
    "currentFormId",
    "dockUserId",
    "dockUserIds",
    "dockEnabled",
    "dockAllowedSites"
  ]);
  Object.entries(config).forEach(([key, value]) => {
    if (skipKeys.has(key) || value == null || value === "") return;
    if (typeof value === "object") return;
    params.set(key, String(value));
  });
  return params;
}

async function sendFormData() {
  const config = await getConfig();
  const headers = {
    "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
  };

  if (config.bearerToken) {
    headers.Authorization = `Bearer ${config.bearerToken}`;
  }

  const start = Date.now();
  const response = await fetch(config.endpoint, {
    method: "POST",
    headers,
    body: toFormBody(config)
  });
  const text = await response.text();

  return {
    ok: response.ok,
    status: response.status,
    timeMs: Date.now() - start,
    body: text
  };
}

function buildClearSessionUrl(config) {
  const endpointUrl = new URL(config.endpoint || DEFAULT_CONFIG.endpoint);
  const serviceId = String(config.serviceId || DEFAULT_CONFIG.serviceId).trim();
  const clearUrl = new URL(`/${encodeURIComponent(serviceId)}/clearsession`, endpointUrl.origin);
  clearUrl.searchParams.set("userId", config.userId || DEFAULT_CONFIG.userId);
  clearUrl.searchParams.set("currency", config.currency || DEFAULT_CONFIG.currency);
  return clearUrl.toString();
}

async function clearSession() {
  const config = await getConfig();
  const headers = {
    Accept: "text/html,application/json,text/plain,*/*",
    "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
  };

  if (config.bearerToken) {
    headers.Authorization = `Bearer ${config.bearerToken}`;
  }

  const body = new URLSearchParams();
  body.set("userId", config.userId || DEFAULT_CONFIG.userId);
  body.set("currency", config.currency || DEFAULT_CONFIG.currency);

  const start = Date.now();
  const url = buildClearSessionUrl(config);
  const response = await fetch(url, {
    method: "POST",
    headers,
    body,
    cache: "no-store",
    credentials: "include"
  });
  const text = await response.text();

  return {
    ok: response.ok,
    url,
    status: response.status,
    timeMs: Date.now() - start,
    body: text
  };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "GET_CONFIG") {
    getConfig().then(sendResponse);
    return true;
  }

  if (message?.type === "SAVE_CONFIG") {
    chrome.storage.local.set(message.config ?? {}).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message?.type === "OPEN_TOOL") {
    chrome.tabs
      .create({ url: message.url || "http://www.rampnhan.online/" })
      .then(() => sendResponse({ ok: true }))
      .catch((error) =>
        sendResponse({ ok: false, error: error instanceof Error ? error.message : "Open failed" })
      );
    return true;
  }

  if (message?.type === "GET_POPUP_STATE") {
    Promise.all([getDockConfig(), chrome.tabs.query({ active: true, currentWindow: true })])
      .then(([config, tabs]) => {
        const tab = tabs[0];
        const suggestedPattern = tab?.url ? sitePatternFromUrl(tab.url) : "";
        sendResponse({
          ok: true,
          url: tab?.url || "",
          suggestedPattern,
          dockEnabled: config.dockEnabled !== false,
          dockAllowedSites: config.dockAllowedSites
        });
      })
      .catch((error) =>
        sendResponse({ ok: false, error: error instanceof Error ? error.message : "Popup failed" })
      );
    return true;
  }

  if (message?.type === "OPEN_DOCK_ON_TAB") {
    chrome.tabs
      .query({ active: true, currentWindow: true })
      .then((tabs) => {
        const tabId = tabs[0]?.id;
        if (!tabId) throw new Error("No active tab");
        return openDockOnTab(tabId);
      })
      .then(sendResponse)
      .catch((error) =>
        sendResponse({ ok: false, error: error instanceof Error ? error.message : "Open dock failed" })
      );
    return true;
  }

  if (message?.type === "ADD_ALLOWED_SITE") {
    saveAllowedSite(message.pattern)
      .then(async (result) => {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tabs[0]?.id) await chrome.tabs.reload(tabs[0].id);
        sendResponse(result);
      })
      .catch((error) =>
        sendResponse({ ok: false, error: error instanceof Error ? error.message : "Save site failed" })
      );
    return true;
  }

  if (message?.type === "OPEN_OPTIONS") {
    chrome.runtime
      .openOptionsPage()
      .then(() => sendResponse({ ok: true }))
      .catch((error) =>
        sendResponse({ ok: false, error: error instanceof Error ? error.message : "Options failed" })
      );
    return true;
  }

  if (message?.type === "GET_FORMS") {
    getForms(message.projectId).then((result) => sendResponse({ ok: true, ...result }));
    return true;
  }

  if (message?.type === "GET_PROJECTS") {
    getProjects().then((result) => sendResponse({ ok: true, ...result }));
    return true;
  }

  if (message?.type === "SAVE_FORMS") {
    const forms = Array.isArray(message.forms) ? message.forms : DEFAULT_FORMS;
    const currentFormId = message.currentFormId || forms[0]?.id || "";
    const currentForm = forms.find((form) => form.id === currentFormId) || forms[0];
    const projects = Array.isArray(message.projects) ? message.projects : undefined;
    const currentProjectId = message.currentProjectId || projects?.[0]?.id || "";
    chrome.storage.local
      .get({ formsByProject: {}, currentFormIdsByProject: {} })
      .then((stored) => {
        const formsByProject = { ...stored.formsByProject };
        const currentFormIdsByProject = { ...stored.currentFormIdsByProject };
        if (currentProjectId) {
          formsByProject[currentProjectId] = forms;
          currentFormIdsByProject[currentProjectId] = currentFormId;
        }
        const patch = {
          ...(currentForm?.config || {}),
          forms,
          currentFormId,
          formsByProject,
          currentFormIdsByProject
        };
        if (projects) patch.projects = projects;
        if (currentProjectId) patch.currentProjectId = currentProjectId;
        return chrome.storage.local.set(patch);
      })
      .then(async () => {
        await broadcastDockData({ forms, currentFormId, projects, currentProjectId });
        sendResponse({ ok: true, forms, currentFormId, projects, currentProjectId });
      });
    return true;
  }

  if (message?.type === "SELECT_PROJECT") {
    const currentProjectId = message.id || "";
    getForms(currentProjectId).then(({ forms, currentFormId }) => {
      chrome.storage.local
        .set({ currentProjectId, forms, currentFormId })
        .then(() => sendResponse({ ok: true, currentProjectId, forms, currentFormId }));
    });
    return true;
  }

  if (message?.type === "SELECT_FORM") {
    getForms().then(({ forms, currentProjectId }) => {
      const form = forms.find((item) => item.id === message.id);
      if (!form) {
        sendResponse({ ok: false, error: "Form not found" });
        return;
      }
      chrome.storage.local
        .get({ currentFormIdsByProject: {} })
        .then((stored) =>
          chrome.storage.local.set({
            ...form.config,
            currentFormId: form.id,
            currentFormIdsByProject: {
              ...stored.currentFormIdsByProject,
              [currentProjectId]: form.id
            }
          })
        )
        .then(() => sendResponse({ ok: true, form }));
    });
    return true;
  }

  if (message?.type === "CLEAR_DATA") {
    clearSession()
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) =>
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Unknown clear session error"
        })
      );
    return true;
  }

  if (message?.type === "SEND_FORM") {
    sendFormData()
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) =>
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Unknown extension request error"
        })
      );
    return true;
  }

  return false;
});
